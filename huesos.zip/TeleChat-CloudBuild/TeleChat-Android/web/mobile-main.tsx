import React from "react";
import { createRoot } from "react-dom/client";
import { TelechatApp } from "./src/components/telechat/app-shell";
import "./src/styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("TeleChat root element not found");
createRoot(root).render(<TelechatApp />);
