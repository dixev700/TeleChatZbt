import { Camera, Check, Lock, Pencil } from "lucide-react";
import { useRef, useState } from "react";
import { Overlay } from "@/components/telechat/sheet";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { ANIMALS, t } from "@/lib/telechat/constants";
import { withAt } from "@/lib/telechat/format";
import { compressImageFile } from "@/lib/telechat/media";
import { isValidDisplayName, isValidUsername, normalizeUsername, usernameError } from "@/lib/telechat/validators";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function ProfileView() {
  const profile = useTelechat((s) => s.profile);
  const [edit, setEdit] = useState<null | "name" | "username" | "bio" | "avatar">(null);
  const fileRef = useRef<HTMLInputElement>(null);
  if (!profile) return null;

  const onGallery = async (file: File | undefined) => {
    if (!file) return;
    const compressed = await compressImageFile(file);
    useTelechat.getState().setAvatar({ kind: "image", src: compressed.dataUrl });
    setEdit(null);
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3">
        <h1 className="text-[28px] font-semibold tracking-tight">{t.profile}</h1>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-10">
        <div className="flex flex-col items-center pt-2">
          <button type="button" onClick={() => setEdit("avatar")} className="relative">
            <UserAvatar avatar={profile.avatar} size="xl" />
            <span className="absolute right-0 bottom-0 flex size-9 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-float)]">
              <Camera className="size-4" />
            </span>
          </button>
          <h2 className="mt-4 text-xl font-semibold tracking-tight">{profile.displayName}</h2>
          <p className="text-sm text-accent">{withAt(profile.username)}</p>
        </div>

        <div className="mt-6 overflow-hidden rounded-3xl bg-surface">
          <FieldRow label={t.editName} value={profile.displayName} onClick={() => setEdit("name")} />
          <FieldRow label={t.editUsername} value={withAt(profile.username)} onClick={() => setEdit("username")} />
          <FieldRow label={t.editBio} value={profile.bio || "Не указано"} onClick={() => setEdit("bio")} />
        </div>
        <div className="mt-3 overflow-hidden rounded-3xl bg-surface">
          <FieldRow
            label={t.devices}
            value={`${useTelechat.getState().devices.length}`}
            onClick={() => useTelechat.getState().setTab("settings")}
          />
          <FieldRow
            label={t.setPin}
            value={profile.pin ? "Включён" : "Выкл"}
            onClick={() => useTelechat.getState().setTab("settings")}
          />
        </div>
        {profile.pin ? (
          <button
            type="button"
            onClick={() => useTelechat.getState().lock()}
            className="tap mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium"
          >
            <Lock className="size-4" />
            {t.lock}
          </button>
        ) : null}
      </div>

      {edit === "avatar" ? (
        <Overlay open onClose={() => setEdit(null)} className="max-h-[86vh] overflow-y-auto">
          <h2 className="text-lg font-semibold">{t.avatar}</h2>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="tap h-11 rounded-2xl bg-surface-2 text-sm font-medium"
            >
              {t.fromGallery}
            </button>
            <button
              type="button"
              onClick={() => {
                useTelechat.getState().setAvatar({
                  kind: "gradient",
                  hue: profile.displayName.length * 19,
                  initials: profile.displayName.slice(0, 2).toUpperCase(),
                });
                setEdit(null);
              }}
              className="tap h-11 rounded-2xl bg-surface-2 text-sm font-medium"
            >
              Инициалы
            </button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            hidden
            onChange={(e) => void onGallery(e.target.files?.[0])}
          />
          <p className="mt-5 text-xs font-medium text-muted">{t.animals}</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {ANIMALS.map((animal) => (
              <button
                key={animal.id}
                type="button"
                onClick={() => {
                  useTelechat.getState().setAnimalAvatar(animal.id);
                  setEdit(null);
                }}
                className={cn(
                  "tap flex flex-col items-center gap-1 rounded-2xl p-2",
                  profile.avatar.kind === "animal" && profile.avatar.animal === animal.id
                    ? "bg-accent-soft"
                    : "bg-surface-2",
                )}
              >
                <UserAvatar avatar={{ kind: "animal", animal: animal.id }} size="md" />
                <span className="text-[11px] text-muted">{animal.label}</span>
              </button>
            ))}
          </div>
        </Overlay>
      ) : null}

      {edit === "name" || edit === "username" || edit === "bio" ? (
        <EditText
          kind={edit}
          initial={edit === "name" ? profile.displayName : edit === "username" ? profile.username : profile.bio}
          onClose={() => setEdit(null)}
        />
      ) : null}
    </div>
  );
}

function FieldRow({ label, value, onClick }: { label: string; value: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="tap flex min-h-14 w-full items-center gap-3 px-4 text-left">
      <span className="flex-1">
        <span className="block text-xs text-muted">{label}</span>
        <span className="block font-medium">{value}</span>
      </span>
      <Pencil className="size-4 text-subtle" />
    </button>
  );
}

function EditText({
  kind,
  initial,
  onClose,
}: {
  kind: "name" | "username" | "bio";
  initial: string;
  onClose: () => void;
}) {
  const [value, setValue] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const save = () => {
    if (kind === "name") {
      if (!isValidDisplayName(value)) {
        setError("Имя: 2–48 символов");
        return;
      }
      useTelechat.getState().updateProfile({ displayName: value.trim() });
    } else if (kind === "username") {
      const err = usernameError(value);
      if (err) {
        setError(err);
        return;
      }
      if (!isValidUsername(value)) {
        setError(t.invalidUsername);
        return;
      }
      const taken = useTelechat
        .getState()
        .contacts.some((c) => c.username === normalizeUsername(value));
      if (taken) {
        setError(t.usernameTaken);
        return;
      }
      useTelechat.getState().updateProfile({ username: normalizeUsername(value) });
    } else {
      useTelechat.getState().updateProfile({ bio: value.trim().slice(0, 140) });
    }
    onClose();
  };
  return (
    <Overlay open onClose={onClose}>
      <h2 className="text-lg font-semibold">
        {kind === "name" ? t.editName : kind === "username" ? t.editUsername : t.editBio}
      </h2>
      <input
        autoFocus
        value={value}
        onChange={(e) => setValue(kind === "username" ? e.target.value.replace(/^@/, "") : e.target.value)}
        className="mt-4 h-12 w-full rounded-2xl bg-surface-2 px-4 text-[16px] outline-none"
      />
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      <button
        type="button"
        onClick={save}
        className="tap mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-2xl bg-accent text-sm font-semibold text-accent-fg"
      >
        <Check className="size-4" />
        {t.save}
      </button>
    </Overlay>
  );
}
