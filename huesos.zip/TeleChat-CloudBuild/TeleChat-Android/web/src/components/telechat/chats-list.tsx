import { Archive, Ban, BellOff, Eraser, Pin, Plus, Search, Trash2, Users } from "lucide-react";
import { useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { ConfirmSheet } from "@/components/telechat/sheet";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { t } from "@/lib/telechat/constants";
import { formatChatTime, formatUnread } from "@/lib/telechat/format";
import { ME_ID } from "@/lib/telechat/ids";
import type { Chat, ChatFilter } from "@/lib/telechat/types";
import { selectVisibleChats, useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

const FILTERS: Array<{ id: ChatFilter; label: string }> = [
  { id: "all", label: "Все" },
  { id: "unread", label: "Непрочитанные" },
  { id: "groups", label: "Группы" },
  { id: "muted", label: "Без звука" },
];

export function ChatsList() {
  const chats = useTelechat(useShallow(selectVisibleChats));
  const query = useTelechat((s) => s.ui.searchQuery);
  const filter = useTelechat((s) => s.ui.chatFilter);
  const archivedCount = useTelechat(
    (s) => s.chats.filter((c) => c.archived && !c.deletedForMe).length,
  );
  const showArchived = useTelechat((s) => s.ui.showArchived);
  const activeChatId = useTelechat((s) => s.ui.activeChatId);
  const [menu, setMenu] = useState<{ chat: Chat; x: number; y: number } | null>(null);
  const [confirm, setConfirm] = useState<null | "delete" | "clear">(null);

  const openMenu = (chat: Chat, x: number, y: number) => {
    setMenu({ chat, x, y });
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3">
        <div className="flex items-center justify-between">
          <h1 className="text-[28px] font-semibold tracking-tight">
            {showArchived ? t.archived : t.chats}
          </h1>
          <div className="flex gap-1">
            <button
              type="button"
              onClick={() => useTelechat.getState().setCreateMode("direct")}
              className="tap flex size-11 items-center justify-center rounded-2xl bg-surface text-fg"
              aria-label={t.newChat}
            >
              <Plus className="size-5" />
            </button>
            <button
              type="button"
              onClick={() => useTelechat.getState().setCreateMode("group")}
              className="tap flex size-11 items-center justify-center rounded-2xl bg-accent text-accent-fg"
              aria-label={t.newGroup}
            >
              <Users className="size-5" />
            </button>
          </div>
        </div>
        <label className="mt-3 flex h-11 items-center gap-2 rounded-2xl bg-surface px-3">
          <Search className="size-4 text-muted" />
          <input
            value={query}
            onChange={(e) => useTelechat.getState().setSearchQuery(e.target.value)}
            placeholder={t.searchChats}
            className="h-full w-full bg-transparent text-[15px] outline-none placeholder:text-subtle"
          />
        </label>
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
          {FILTERS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => useTelechat.getState().setChatFilter(item.id)}
              className={cn(
                "tap h-8 shrink-0 rounded-full px-3 text-xs font-medium transition-colors duration-200",
                filter === item.id ? "bg-accent text-accent-fg" : "bg-surface text-muted",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-2">
        {!showArchived && archivedCount > 0 ? (
          <button
            type="button"
            onClick={() => useTelechat.getState().setShowArchived(true)}
            className="tap mb-1 flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left hover:bg-surface"
          >
            <span className="flex size-12 items-center justify-center rounded-full bg-surface-2 text-muted">
              <Archive className="size-5" />
            </span>
            <span className="flex-1">
              <span className="block font-medium">{t.archive}</span>
              <span className="text-sm text-muted">{archivedCount}</span>
            </span>
          </button>
        ) : null}
        {showArchived ? (
          <button
            type="button"
            onClick={() => useTelechat.getState().setShowArchived(false)}
            className="tap mb-2 px-3 text-sm font-medium text-accent"
          >
            К чатам
          </button>
        ) : null}
        {chats.length === 0 ? (
          <div className="flex h-[48vh] flex-col items-center justify-center px-8 text-center">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-surface">
              <Search className="size-6 text-muted" />
            </div>
            <p className="mt-4 font-semibold">{showArchived ? t.emptyArchive : t.emptyChats}</p>
            <p className="mt-1 text-sm text-muted">{t.emptyChatsHint}</p>
          </div>
        ) : (
          chats.map((chat, index) => (
            <button
              key={chat.id}
              type="button"
              onClick={() => useTelechat.getState().openChat(chat.id)}
              onContextMenu={(e) => {
                e.preventDefault();
                openMenu(chat, e.clientX, e.clientY);
              }}
              onTouchStart={(event) => {
                const touch = event.touches[0];
                const timer = window.setTimeout(() => {
                  if (touch) openMenu(chat, touch.clientX, touch.clientY);
                }, 380);
                const clear = () => window.clearTimeout(timer);
                event.currentTarget.addEventListener("touchend", clear, { once: true });
                event.currentTarget.addEventListener("touchmove", clear, { once: true });
              }}
              className={cn(
                "tap rise-in flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors duration-200",
                activeChatId === chat.id ? "bg-surface" : "hover:bg-surface/70",
              )}
              style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}
            >
              <UserAvatar avatar={chat.avatar} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1.5">
                  <span className="truncate font-semibold tracking-tight">{chat.title}</span>
                  {chat.muted ? <BellOff className="size-3.5 text-subtle" /> : null}
                  {chat.pinned ? <Pin className="size-3.5 text-subtle" /> : null}
                </span>
                <span className="mt-0.5 block truncate text-sm text-muted">
                  {chat.lastMessagePreview || "Нет сообщений"}
                </span>
              </span>
              <span className="flex flex-col items-end gap-1">
                <span className="text-[11px] text-subtle">{formatChatTime(chat.lastMessageAt)}</span>
                {chat.unread > 0 ? (
                  <span
                    className={cn(
                      "min-w-5 rounded-full px-1.5 text-center text-[11px] font-semibold",
                      chat.muted ? "bg-subtle text-bg" : "bg-accent text-accent-fg",
                    )}
                  >
                    {formatUnread(chat.unread)}
                  </span>
                ) : null}
              </span>
            </button>
          ))
        )}
      </div>

      {menu ? (
        <div className="fixed inset-0 z-40" onClick={() => setMenu(null)}>
          <div
            className="absolute w-56 scale-in overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-float)]"
            style={{
              left: Math.min(menu.x, (typeof window !== "undefined" ? window.innerWidth : 400) - 240),
              top: Math.min(menu.y, (typeof window !== "undefined" ? window.innerHeight : 700) - 260),
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <MenuRow
              icon={Pin}
              label={menu.chat.pinned ? t.unpin : t.pin}
              onClick={() => {
                useTelechat.getState().pinChat(menu.chat.id, !menu.chat.pinned);
                setMenu(null);
              }}
            />
            <MenuRow
              icon={Eraser}
              label={t.clearHistory}
              onClick={() => {
                setConfirm("clear");
              }}
            />
            {menu.chat.type === "direct" && !menu.chat.participantIds.includes("user_telechat") ? (
              <MenuRow
                icon={Ban}
                label={t.block}
                onClick={() => {
                  const peerId = menu.chat.participantIds.find((id) => id !== ME_ID);
                  if (peerId) useTelechat.getState().blockContact(peerId, true);
                  setMenu(null);
                }}
              />
            ) : null}
            <MenuRow
              icon={Trash2}
              label="Удалить чат"
              danger
              onClick={() => setConfirm("delete")}
            />
          </div>
        </div>
      ) : null}

      {confirm === "delete" && menu ? (
        <ConfirmSheet
          title="Удалить чат"
          body="Переписка исчезнет из списка."
          confirmLabel={t.delete}
          danger
          onClose={() => {
            setConfirm(null);
            setMenu(null);
          }}
          onConfirm={() => {
            useTelechat.getState().deleteChat(menu.chat.id, false);
            setConfirm(null);
            setMenu(null);
          }}
        />
      ) : null}
      {confirm === "clear" && menu ? (
        <ConfirmSheet
          title={t.clearHistory}
          body="Все сообщения в этом чате будут удалены у вас."
          confirmLabel={t.clearHistory}
          danger
          onClose={() => {
            setConfirm(null);
            setMenu(null);
          }}
          onConfirm={() => {
            useTelechat.getState().clearHistory(menu.chat.id);
            setConfirm(null);
            setMenu(null);
          }}
        />
      ) : null}
    </div>
  );
}

function MenuRow({
  icon: Icon,
  label,
  onClick,
  danger,
}: {
  icon: typeof Pin;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-12 w-full items-center gap-3 px-3 text-sm transition-colors duration-150 hover:bg-surface-2",
        danger ? "text-danger" : "text-fg",
      )}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}