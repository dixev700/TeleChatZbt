import { ImagePlus, Mic, Paperclip, Send, Square, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { RecordingMeter } from "@/components/telechat/voice-player";
import { createRecorder, storeVoiceBlob } from "@/lib/telechat/audio";
import { t } from "@/lib/telechat/constants";
import { storeImageFile, storeVideoFile } from "@/lib/telechat/media";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function Composer({ chatId }: { chatId: string }) {
  const draft = useTelechat((s) => s.drafts[chatId]);
  const setDraft = useTelechat((s) => s.setDraft);
  const sendText = useTelechat((s) => s.sendText);
  const sendVoice = useTelechat((s) => s.sendVoice);
  const sendPhoto = useTelechat((s) => s.sendPhoto);
  const sendVideo = useTelechat((s) => s.sendVideo);
  const replyTo = useTelechat((s) => {
    const id = s.drafts[chatId]?.replyToId;
    if (!id) return null;
    return (s.messages[chatId] ?? []).find((m) => m.id === id) ?? null;
  });
  const fileRef = useRef<HTMLInputElement>(null);
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const recorderRef = useRef<ReturnType<typeof createRecorder> | null>(null);
  const tickRef = useRef<number | null>(null);

  const text = draft?.text ?? "";
  const canSend = text.trim().length > 0;

  useEffect(() => {
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
      recorderRef.current?.cancel();
    };
  }, []);

  const startRec = async () => {
    const rec = createRecorder();
    recorderRef.current = rec;
    try {
      await rec.start();
      setRecording(true);
      const started = Date.now();
      tickRef.current = window.setInterval(() => setElapsed(Date.now() - started), 200);
    } catch {
      setRecording(false);
    }
  };

  const stopRec = async () => {
    if (!recorderRef.current) return;
    if (tickRef.current) window.clearInterval(tickRef.current);
    try {
      const result = await recorderRef.current.stop();
      const stored = await storeVoiceBlob(result.blob, result.durationMs, result.peaks);
      sendVoice(chatId, stored.mediaId, stored.durationMs, stored.peaks);
    } catch {
      /* cancelled */
    }
    setRecording(false);
    setElapsed(0);
  };

  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    for (const file of Array.from(files)) {
      if (file.type.startsWith("image/")) {
        const stored = await storeImageFile(file);
        sendPhoto(chatId, stored.mediaId, stored.width, stored.height);
      } else if (file.type.startsWith("video/")) {
        const stored = await storeVideoFile(file);
        sendVideo(chatId, stored.mediaId, stored.durationMs, stored.width, stored.height);
      }
    }
  };

  return (
    <div className="border-t border-border bg-bg-elevated px-3 pt-2 pb-[max(0.6rem,env(safe-area-inset-bottom))]">
      {replyTo ? (
        <div className="mb-2 flex items-center gap-2 rounded-2xl bg-surface px-3 py-2">
          <div className="min-w-0 flex-1 border-l-2 border-accent pl-2">
            <div className="text-[11px] font-medium text-accent">Ответ</div>
            <div className="truncate text-xs text-muted">{replyTo.text || "Медиа"}</div>
          </div>
          <button
            type="button"
            className="tap size-8 rounded-full text-muted"
            onClick={() => setDraft(chatId, text, null)}
            aria-label="Сбросить ответ"
          >
            <X className="mx-auto size-4" />
          </button>
        </div>
      ) : null}
      {recording ? (
        <div className="mb-2 flex items-center justify-between rounded-2xl bg-surface px-3 py-2">
          <RecordingMeter peaks={[]} elapsedMs={elapsed} />
          <button
            type="button"
            onClick={() => void stopRec()}
            className="tap flex size-11 items-center justify-center rounded-full bg-danger text-white"
            aria-label="Остановить запись"
          >
            <Square className="size-4 fill-current" />
          </button>
        </div>
      ) : null}
      <div className="flex items-end gap-2">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="tap flex size-11 shrink-0 items-center justify-center rounded-2xl bg-surface text-muted"
          aria-label={t.attach}
        >
          <Paperclip className="size-5" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/*"
          multiple
          hidden
          onChange={(e) => void onFiles(e.target.files)}
        />
        <div className="flex min-w-0 flex-1 items-end rounded-2xl bg-surface px-3 py-1.5">
          <textarea
            value={text}
            rows={1}
            placeholder={t.messagePlaceholder}
            onChange={(e) => setDraft(chatId, e.target.value, draft?.replyToId ?? null)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendText(chatId, text);
              }
            }}
            className="max-h-32 min-h-10 w-full resize-none bg-transparent py-2 text-[15px] outline-none"
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="tap mb-1 flex size-9 items-center justify-center rounded-xl text-muted"
            aria-label={t.photo}
          >
            <ImagePlus className="size-5" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => {
            if (canSend) sendText(chatId, text);
            else void startRec();
          }}
          className={cn(
            "tap flex size-11 shrink-0 items-center justify-center rounded-2xl",
            canSend ? "bg-accent text-accent-fg" : "bg-surface text-muted",
          )}
          aria-label={canSend ? t.send : t.record}
        >
          {canSend ? <Send className="size-5" /> : <Mic className="size-5" />}
        </button>
      </div>
    </div>
  );
}
