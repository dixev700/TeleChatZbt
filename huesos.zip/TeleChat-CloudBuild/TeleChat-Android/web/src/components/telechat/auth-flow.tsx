import { ArrowLeft, Mail } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { TelechatMark } from "@/components/telechat/logo";
import { CodeSlots, NumericKeypad, PinDots } from "@/components/telechat/numeric-keypad";
import { t } from "@/lib/telechat/constants";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function AuthFlow() {
  const step = useTelechat((s) => s.authStep);
  if (step === "welcome") return <WelcomeScreen />;
  if (step === "code") return <CodeScreen />;
  if (step === "username") return <UsernameScreen />;
  return <EmailScreen />;
}

function Shell({
  children,
  onBack,
  step,
}: {
  children: ReactNode;
  onBack?: () => void;
  step: number;
}) {
  return (
    <div className="app-wallpaper-ink flex min-h-dvh flex-col px-5 pb-8 pt-[max(1.5rem,env(safe-area-inset-top))]">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col">
        <div className="flex items-center justify-between">
          {onBack ? (
            <button
              type="button"
              onClick={onBack}
              className="tap flex size-11 items-center justify-center rounded-2xl bg-surface text-fg"
              aria-label="Назад"
            >
              <ArrowLeft className="size-5" />
            </button>
          ) : (
            <span className="size-11" />
          )}
          <TelechatMark className="size-16" />
          <span className="size-11" />
        </div>
        <div className="mt-6 flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className={cn(
                "h-1 flex-1 rounded-full transition-colors duration-200",
                i <= step ? "bg-accent" : "bg-surface-2",
              )}
            />
          ))}
        </div>
        {children}
      </div>
    </div>
  );
}

function EmailScreen() {
  const email = useTelechat((s) => s.ui.authEmail);
  const error = useTelechat((s) => s.ui.authError);
  const setAuthEmail = useTelechat((s) => s.setAuthEmail);
  const requestCode = useTelechat((s) => s.requestCode);

  return (
    <Shell step={0}>
      <h1 className="rise-in mt-10 text-[32px] font-semibold leading-tight tracking-tight">
        {t.emailTitle}
      </h1>
      <p className="rise-in rise-in-1 mt-3 text-sm leading-relaxed text-muted">{t.emailHint}</p>
      <label className="rise-in rise-in-2 mt-8 block">
        <span className="mb-2 flex items-center gap-2 text-xs font-medium text-muted">
          <Mail className="size-3.5" /> Почта
        </span>
        <input
          autoFocus
          type="email"
          inputMode="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setAuthEmail(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") requestCode();
          }}
          placeholder={t.emailPlaceholder}
          className="h-12 w-full rounded-2xl border border-border bg-surface px-4 text-[16px] outline-none ring-accent transition-[box-shadow] focus:ring-2"
        />
      </label>
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      <button
        type="button"
        onClick={() => requestCode()}
        className="tap rise-in rise-in-3 mt-auto h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg"
      >
        {t.continue}
      </button>
    </Shell>
  );
}

function CodeScreen() {
  const email = useTelechat((s) => s.ui.authEmail);
  const code = useTelechat((s) => s.ui.authCode);
  const expected = useTelechat((s) => s.ui.authExpectedCode);
  const error = useTelechat((s) => s.ui.authError);
  const setAuthCode = useTelechat((s) => s.setAuthCode);
  const verifyCode = useTelechat((s) => s.verifyCode);

  useEffect(() => {
    if (code.length === 4) verifyCode();
  }, [code, verifyCode]);

  return (
    <Shell
      step={1}
      onBack={() => useTelechat.setState({ authStep: "email" })}
    >
      <div className="rise-in mt-6 rounded-3xl bg-accent-soft px-4 py-4 text-center">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">{t.yourCode}</p>
        <p className="mt-1 text-[40px] font-semibold tabular-nums tracking-[0.28em] text-fg">
          {expected}
        </p>
      </div>
      <h1 className="rise-in rise-in-1 mt-6 text-[26px] font-semibold leading-tight tracking-tight">
        {t.codeTitle}
      </h1>
      <p className="rise-in rise-in-1 mt-2 text-sm leading-relaxed text-muted">
        {t.codeHint} <span className="text-fg">{email}</span>
      </p>
      <div className="rise-in rise-in-2 mt-6">
        <CodeSlots value={code} length={4} />
      </div>
      {error ? <p className="mt-3 text-center text-sm text-danger">{error}</p> : null}
      <div className="mt-auto pt-6">
        <NumericKeypad
          onDigit={(d) => setAuthCode(code + d)}
          onBackspace={() => setAuthCode(code.slice(0, -1))}
        />
      </div>
    </Shell>
  );
}

function UsernameScreen() {
  const name = useTelechat((s) => s.ui.authName);
  const username = useTelechat((s) => s.ui.authUsername);
  const error = useTelechat((s) => s.ui.authError);
  const setAuthName = useTelechat((s) => s.setAuthName);
  const setAuthUsername = useTelechat((s) => s.setAuthUsername);
  const completeProfile = useTelechat((s) => s.completeProfile);

  return (
    <Shell
      step={2}
      onBack={() => useTelechat.setState({ authStep: "code" })}
    >
      <h1 className="rise-in mt-10 text-[32px] font-semibold leading-tight tracking-tight">
        {t.usernameTitle}
      </h1>
      <p className="rise-in rise-in-1 mt-3 text-sm leading-relaxed text-muted">{t.usernameHint}</p>
      <label className="rise-in rise-in-2 mt-8 block">
        <span className="mb-2 block text-xs font-medium text-muted">{t.namePlaceholder}</span>
        <input
          autoFocus
          value={name}
          onChange={(e) => setAuthName(e.target.value)}
          placeholder="Анна"
          className="h-12 w-full rounded-2xl border border-border bg-surface px-4 text-[16px] outline-none ring-accent focus:ring-2"
        />
      </label>
      <label className="mt-4 block">
        <span className="mb-2 block text-xs font-medium text-muted">Юзернейм</span>
        <div className="flex h-12 items-center rounded-2xl border border-border bg-surface px-4 ring-accent focus-within:ring-2">
          <span className="text-muted">@</span>
          <input
            value={username}
            onChange={(e) => setAuthUsername(e.target.value)}
            placeholder="username"
            className="h-full w-full bg-transparent pl-1 text-[16px] outline-none"
          />
        </div>
      </label>
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      <button
        type="button"
        onClick={() => completeProfile()}
        className="tap mt-auto h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg"
      >
        {t.start}
      </button>
    </Shell>
  );
}

function WelcomeScreen() {
  const name = useTelechat((s) => s.profile?.displayName ?? "");
  const finishWelcome = useTelechat((s) => s.finishWelcome);

  useEffect(() => {
    const timer = setTimeout(() => finishWelcome(), 1800);
    return () => clearTimeout(timer);
  }, [finishWelcome]);

  return (
    <div className="app-wallpaper-ink flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <TelechatMark className="rise-in size-28" />
      <h1 className="rise-in rise-in-2 mt-8 text-[34px] font-semibold tracking-tight">
        {t.welcome}
      </h1>
      <p className="rise-in rise-in-3 mt-3 max-w-sm text-sm leading-relaxed text-muted">
        {name ? `${name}, всё готово.` : t.welcomeSub} Можно писать, записывать голос и делиться кадрами.
      </p>
      <button
        type="button"
        onClick={finishWelcome}
        className="tap rise-in rise-in-4 mt-10 h-12 rounded-2xl bg-accent px-8 text-[15px] font-semibold text-accent-fg"
      >
        Перейти к чатам
      </button>
    </div>
  );
}

export function Splash() {
  return (
    <div className="app-wallpaper-ink flex min-h-dvh flex-col items-center justify-center">
      <TelechatMark className="size-16" />
      <p className="mt-5 text-lg font-semibold tracking-tight">TeleChat</p>
    </div>
  );
}

export function PinLock() {
  const pinInput = useTelechat((s) => s.ui.pinInput);
  const error = useTelechat((s) => s.ui.pinError);
  const setPinInput = useTelechat((s) => s.setPinInput);
  const unlock = useTelechat((s) => s.unlock);

  useEffect(() => {
    if (pinInput.length === 6) unlock(pinInput);
  }, [pinInput, unlock]);

  return (
    <div className="app-wallpaper-ink flex min-h-dvh flex-col px-6 pt-16 pb-8">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col">
        <TelechatMark className="mx-auto size-20" />
        <h1 className="mt-8 text-center text-2xl font-semibold tracking-tight">{t.enterPin}</h1>
        <div className="mt-8">
          <PinDots value={pinInput} length={6} />
        </div>
        {error ? <p className="mt-4 text-center text-sm text-danger">{error}</p> : null}
        <div className="mt-auto pt-8">
          <NumericKeypad
            onDigit={(d) => setPinInput(pinInput + d)}
            onBackspace={() => setPinInput(pinInput.slice(0, -1))}
          />
        </div>
      </div>
    </div>
  );
}
