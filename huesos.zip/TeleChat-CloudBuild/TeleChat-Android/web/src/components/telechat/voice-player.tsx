import { Pause, Play } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { formatDuration } from "@/lib/telechat/format";
import { getMedia } from "@/lib/telechat/storage";
import type { VoicePayload } from "@/lib/telechat/types";
import { cn } from "@/lib/utils";

export function VoicePlayer({
  voice,
  outgoing,
}: {
  voice: VoicePayload;
  outgoing?: boolean;
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    let active = true;
    void getMedia(voice.mediaId).then((value) => {
      if (active) setSrc(value);
    });
    return () => {
      active = false;
    };
  }, [voice.mediaId]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTime = () => {
      setCurrent(audio.currentTime * 1000);
      setProgress(audio.duration ? audio.currentTime / audio.duration : 0);
    };
    const onEnd = () => {
      setPlaying(false);
      setProgress(0);
      setCurrent(0);
    };
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("ended", onEnd);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("ended", onEnd);
    };
  }, [src]);

  const toggle = async () => {
    const audio = audioRef.current;
    if (!audio || !src) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
      return;
    }
    await audio.play();
    setPlaying(true);
  };

  return (
    <div className="flex min-w-[210px] items-center gap-3">
      {src ? <audio ref={audioRef} src={src} preload="metadata" /> : null}
      <button
        type="button"
        onClick={() => void toggle()}
        className={cn(
          "tap flex size-11 shrink-0 items-center justify-center rounded-full",
          outgoing ? "bg-white/15 text-white" : "bg-accent text-accent-fg",
        )}
        aria-label={playing ? "Пауза" : "Слушать"}
      >
        {playing ? <Pause className="size-4 fill-current" /> : <Play className="ml-0.5 size-4 fill-current" />}
      </button>
      <div className="min-w-0 flex-1">
        <div className="flex h-7 items-end gap-[3px]">
          {voice.peaks.map((peak, i) => {
            const active = i / voice.peaks.length <= progress;
            return (
              <span
                key={i}
                className={cn(
                  "w-[3px] rounded-full",
                  active
                    ? outgoing
                      ? "bg-white"
                      : "bg-accent"
                    : outgoing
                      ? "bg-white/35"
                      : "bg-fg/25",
                )}
                style={{ height: `${Math.max(18, peak * 100)}%` }}
              />
            );
          })}
        </div>
        <div className={cn("mt-1 text-[11px] tabular-nums", outgoing ? "text-white/70" : "text-muted")}>
          {formatDuration(playing || current > 0 ? current : voice.durationMs)}
        </div>
      </div>
    </div>
  );
}

export function RecordingMeter({ peaks, elapsedMs }: { peaks: number[]; elapsedMs: number }) {
  return (
    <div className="flex items-center gap-3">
      <span className="size-2.5 animate-pulse rounded-full bg-danger" />
      <div className="flex h-7 items-end gap-[3px]">
        {(peaks.length ? peaks : Array.from({ length: 24 }, () => 0.2)).slice(-24).map((peak, i) => (
          <span
            key={i}
            className="wave-bar w-[3px] rounded-full bg-danger/80"
            style={{ height: `${Math.max(20, peak * 100)}%`, animationDelay: `${i * 40}ms` }}
          />
        ))}
      </div>
      <span className="text-sm tabular-nums text-danger">{formatDuration(elapsedMs)}</span>
    </div>
  );
}
