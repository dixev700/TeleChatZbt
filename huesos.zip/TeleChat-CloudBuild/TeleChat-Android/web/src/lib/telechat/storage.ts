import { STORAGE_KEY } from "./constants";
import type { PersistedState } from "./types";

export function readPersisted(): PersistedState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedState;
    if (!parsed || parsed.version !== 1) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writePersisted(state: PersistedState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.warn("[telechat] persist failed", error);
    try {
      const slim: PersistedState = {
        ...state,
        messages: Object.fromEntries(
          Object.entries(state.messages).map(([id, list]) => [
            id,
            list.map((m) =>
              m.type === "photo" || m.type === "video" || m.type === "voice"
                ? { ...m, photo: undefined, video: undefined, voice: undefined, text: m.text || "Медиа" }
                : m,
            ),
          ]),
        ),
      };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
    } catch {
      /* quota exhausted */
    }
  }
}

export function clearPersisted(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_KEY);
}

const memoryMedia = new Map<string, string>();

function openMediaDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === "undefined") return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open("telechat-blobs", 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("media")) {
          db.createObjectStore("media");
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function putMedia(id: string, dataUrl: string): Promise<void> {
  memoryMedia.set(id, dataUrl);
  const db = await openMediaDb();
  if (!db) {
    try {
      localStorage.setItem(`telechat.media.${id}`, dataUrl);
    } catch {
      /* ignore */
    }
    return;
  }
  await new Promise<void>((resolve) => {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").put(dataUrl, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}

export async function getMedia(id: string): Promise<string | null> {
  if (memoryMedia.has(id)) return memoryMedia.get(id) ?? null;
  const db = await openMediaDb();
  if (!db) {
    try {
      return localStorage.getItem(`telechat.media.${id}`);
    } catch {
      return null;
    }
  }
  return new Promise((resolve) => {
    const tx = db.transaction("media", "readonly");
    const req = tx.objectStore("media").get(id);
    req.onsuccess = () => {
      const value = (req.result as string | undefined) ?? null;
      if (value) memoryMedia.set(id, value);
      resolve(value);
    };
    req.onerror = () => resolve(null);
  });
}

export async function deleteMedia(id: string): Promise<void> {
  memoryMedia.delete(id);
  const db = await openMediaDb();
  if (!db) {
    try {
      localStorage.removeItem(`telechat.media.${id}`);
    } catch {
      /* ignore */
    }
    return;
  }
  await new Promise<void>((resolve) => {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}
