import type {
  AnimalId,
  ComingSoonFeature,
  ReactionId,
} from "./types";

export const APP_NAME = "TeleChat";
export const STORAGE_KEY = "telechat.v1";
export const MEDIA_DB = "telechat-media";
export const USERNAME_MIN = 5;
export const USERNAME_MAX = 32;
export const PIN_LENGTH = 6;
export const MAX_VOICE_MS = 60_000;
export const MAX_IMAGE_EDGE = 1280;
export const CODE_LENGTH = 4;

export const REACTIONS: Array<{
  id: ReactionId;
  label: string;
}> = [
  { id: "heart", label: "Нравится" },
  { id: "like", label: "Ок" },
  { id: "fire", label: "Огонь" },
  { id: "laugh", label: "Смешно" },
  { id: "wow", label: "Вау" },
  { id: "sad", label: "Жаль" },
];

export const ANIMALS: Array<{
  id: AnimalId;
  label: string;
  hue: number;
}> = [
  { id: "fox", label: "Лиса", hue: 22 },
  { id: "cat", label: "Кот", hue: 28 },
  { id: "owl", label: "Сова", hue: 210 },
  { id: "bear", label: "Медведь", hue: 28 },
  { id: "panda", label: "Панда", hue: 0 },
  { id: "wolf", label: "Волк", hue: 220 },
  { id: "rabbit", label: "Кролик", hue: 340 },
  { id: "whale", label: "Кит", hue: 205 },
  { id: "bird", label: "Птица", hue: 48 },
  { id: "tiger", label: "Тигр", hue: 30 },
  { id: "frog", label: "Лягушка", hue: 120 },
  { id: "dog", label: "Пёс", hue: 32 },
  { id: "deer", label: "Олень", hue: 18 },
  { id: "penguin", label: "Пингвин", hue: 210 },
  { id: "koala", label: "Коала", hue: 40 },
  { id: "otter", label: "Выдра", hue: 24 },
];

export const COMING_SOON: Record<
  ComingSoonFeature,
  { title: string; body: string }
> = {
  calls: {
    title: "Звонки",
    body: "Голосовые и видеозвонки появятся в следующем обновлении TeleChat.",
  },
  stories: {
    title: "Истории",
    body: "Короткие истории на 24 часа уже в разработке — следите за обновлениями.",
  },
  channels: {
    title: "Каналы",
    body: "Публичные каналы для трансляций и новостей появятся позже.",
  },
  secret: {
    title: "Секретные чаты",
    body: "Сквозное шифрование с таймером самоуничтожения пока в разработке.",
  },
  payments: {
    title: "Платежи",
    body: "Переводы и чаевые внутри TeleChat ещё не подключены.",
  },
  bots: {
    title: "Боты",
    body: "Каталог ботов и мини-приложений появится в одной из следующих версий.",
  },
  stickers: {
    title: "Стикеры",
    body: "Наборы стикеров и анимированные реакции скоро будут доступны.",
  },
  export: {
    title: "Экспорт чата",
    body: "Выгрузка истории в файл появится вместе с облачным архивом.",
  },
  folders: {
    title: "Папки чатов",
    body: "Свои папки и фильтры можно будет настроить в следующем релизе.",
  },
  "live-location": {
    title: "Геолокация",
    body: "Отправка точки на карте и живая геолокация пока недоступны.",
  },
  polls: {
    title: "Опросы",
    body: "Опросы в группах появятся вместе с викторинами.",
  },
  translation: {
    title: "Перевод",
    body: "Автоперевод сообщений ещё в разработке.",
  },
};

export const WALLPAPERS = [
  { id: "ink", label: "Чернила" },
  { id: "dusk", label: "Сумерки" },
  { id: "mist", label: "Туман" },
  { id: "tide", label: "Прилив" },
  { id: "paper", label: "Бумага" },
] as const;

export type WallpaperId = (typeof WALLPAPERS)[number]["id"];

export const t = {
  appName: APP_NAME,
  welcome: "Добро пожаловать в TeleChat!",
  welcomeSub: "Сообщения, голос и медиа — всё на одном экране.",
  emailTitle: "Вход в TeleChat",
  emailHint: "Укажите почту — отправим код подтверждения.",
  emailPlaceholder: "you@mail.com",
  continue: "Продолжить",
  codeTitle: "Код подтверждения",
  codeHint: "Мы отправили 4-значный код на",
  codeDemo: "Код показан сверху — он свой для каждого входа",
  yourCode: "Ваш код",
  usernameTitle: "Как к вам обращаться?",
  usernameHint: "Имя видно в чатах. Юзернейм нужен, чтобы вас находили.",
  namePlaceholder: "Имя",
  usernamePlaceholder: "username",
  start: "Начать",
  chats: "Чаты",
  contacts: "Контакты",
  settings: "Настройки",
  profile: "Профиль",
  you: "Вы",
  searchChats: "Поиск по чатам",
  searchContacts: "Поиск контактов и @username",
  newChat: "Новый чат",
  newGroup: "Новая группа",
  archive: "Архив",
  archived: "Архив чатов",
  mute: "Отключить уведомления",
  unmute: "Включить уведомления",
  pin: "Закрепить",
  unpin: "Открепить",
  delete: "Удалить",
  deleteForMe: "Удалить у себя",
  deleteForAll: "Удалить у всех",
  copy: "Копировать",
  forward: "Переслать",
  reply: "Ответить",
  messagePlaceholder: "Сообщение",
  emptyChats: "Пока нет переписок",
  emptyChatsHint: "Начните чат с контакта или создайте группу.",
  emptyContacts: "Никого не нашлось",
  emptyArchive: "Архив пуст",
  emptyMessages: "Напишите первое сообщение",
  inDevelopment: "Эта функция в разработке",
  online: "в сети",
  typing: "печатает",
  members: "участников",
  save: "Сохранить",
  cancel: "Отмена",
  done: "Готово",
  logout: "Выйти",
  lock: "Заблокировать",
  setPin: "Код-пароль",
  pinHint: "Шесть цифр для быстрого доступа",
  pinRepeat: "Повторите код",
  pinMismatch: "Коды не совпали. Попробуйте ещё раз",
  clearHistory: "Очистить историю",
  block: "Заблокировать",
  devices: "Устройства",
  theme: "Оформление",
  dark: "Тёмная",
  light: "Светлая",
  editName: "Имя",
  editUsername: "Имя пользователя",
  editBio: "О себе",
  avatar: "Аватар",
  fromGallery: "Из галереи",
  animals: "Животные",
  notifications: "Уведомления",
  privacy: "Конфиденциальность",
  appearance: "Оформление",
  dataStorage: "Данные и память",
  language: "Язык",
  help: "Помощь",
  about: "О TeleChat",
  voiceNote: "Голосовое сообщение",
  photo: "Фото",
  video: "Видео",
  today: "Сегодня",
  yesterday: "Вчера",
  justNow: "только что",
  groupName: "Название группы",
  addMembers: "Участники",
  create: "Создать",
  noResults: "Ничего не найдено",
  copied: "Скопировано",
  deleted: "Сообщение удалено",
  forwarded: "Переслано",
  sent: "Отправлено",
  delivered: "Доставлено",
  read: "Прочитано",
  blocked: "В чёрном списке",
  unblock: "Разблокировать",
  lastSeen: "был(а)",
  enterPin: "Введите код-пароль",
  wrongPin: "Неверный код",
  wrongCode: "Неверный код",
  invalidEmail: "Проверьте адрес почты",
  invalidName: "Имя не может быть пустым",
  invalidUsername: "Юзернейм: 5–32 символа, латиница, цифры и _",
  usernameTaken: "Этот юзернейм уже занят",
  chatDeleted: "Чат удалён",
  chatArchived: "Чат в архиве",
  notificationsOff: "Уведомления выключены",
  notificationsOn: "Уведомления включены",
  selectChat: "Выберите чат",
  selectChatHint: "Или создайте новый — справа ничего нет, пока вы не откроете переписку.",
  mediaEmpty: "В этом чате ещё нет медиа",
  attach: "Вложение",
  record: "Запись",
  send: "Отправить",
  stop: "Стоп",
  currentDevice: "Это устройство",
  terminate: "Завершить сеанс",
  russian: "Русский",
  fontSize: "Размер шрифта",
  wallpaper: "Фон чата",
  readReceipts: "Отчёты о прочтении",
  lastSeenPrivacy: "Время последнего визита",
  sound: "Звук уведомлений",
  everyone: "Все",
  contactsOnly: "Контакты",
  nobody: "Никто",
  small: "Меньше",
  medium: "Обычно",
  large: "Крупнее",
  version: "Версия 1.0",
  official: "официальный",
  groupCreated: "Группа создана",
  youDeletedChat: "Вы удалили этот чат",
  messageCopied: "Текст скопирован",
  holdToRecord: "Удерживайте, чтобы записать",
  slideToCancel: "Отпустите, чтобы отправить",
} as const;
