#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/web"
npm ci
npm run mobile:build
cd "$ROOT"
rm -rf android/app/src/main/assets/www
mkdir -p android/app/src/main/assets/www
cp -R web/dist-mobile/. android/app/src/main/assets/www/
cd android
gradle assembleDebug --no-daemon
