# TeleChat — Android project

Проект подготовлен из исходного ZIP как Android WebView-приложение. Исходный React/TypeScript интерфейс сохраняется в `web/`, Android-обёртка находится в `android/`.

## Сборка

1. Откройте `android/` в Android Studio.
2. В каталоге `web/` выполните `npm ci`.
3. Выполните `npm run mobile:build`.
4. Скопируйте содержимое `web/dist-mobile/` в `android/app/src/main/assets/www/`.
5. В Android Studio: **Build → Generate App Bundles or APKs → Generate APKs**.

Или используйте `build-android.sh`, если в `android/` добавлен Gradle wrapper (`gradlew`).

## Важно

Это упаковка текущего клиентского TeleChat в локальный Android WebView. Серверные функции исходного workspace (если они используются) не становятся автоматически локальным backend. Для настоящего многопользовательского мессенджера потребуется отдельный backend/API и push-уведомления.
