# TeleChat — облачная сборка APK

Этот проект подготовлен для сборки APK без Android Studio и без Termux на телефоне.

## Самый простой способ: GitHub Actions

1. Создай бесплатный аккаунт GitHub.
2. Создай новый репозиторий (например `TeleChat`).
3. Загрузи **содержимое этой папки `TeleChat-Android`** в репозиторий. Важно: папка `.github/workflows` тоже должна быть загружена.
4. Открой вкладку **Actions**.
5. Выбери workflow **Build TeleChat APK**.
6. Нажми **Run workflow**.
7. После завершения открой выполненный workflow.
8. Внизу страницы в разделе **Artifacts** скачай `TeleChat-debug-apk`.
9. Внутри будет `app-debug.apk` — его можно установить на Android.

Workflow автоматически:
- устанавливает Node.js;
- выполняет `npm ci`;
- собирает React/TypeScript-версию TeleChat через Vite;
- помещает сборку в Android assets;
- устанавливает Java 17, Android SDK и Gradle 8.13;
- собирает debug APK;
- прикрепляет APK как Artifact.

## Важно

Это debug APK для тестирования. Для публикации в Google Play понадобится отдельная release-сборка с подписью ключом.
